let chocolate = document.getElementById("chocolate");
let strawberry = document.getElementById("strawberry");
let pista = document.getElementById("pista");
let oreo = document.getElementById("oreo");


chocolate.addEventListener('click', () => {
    alert("You have purchased the Chocolate Icecream");
});

strawberry.addEventListener('click', () => {
    alert("You have purchased the Strawberry Icecream");
});

pista.addEventListener('click', () => {
    alert("You have purchased the Pista Icecream");
});

oreo.addEventListener('click', () => {
    alert("You have purchased the Oreo Icecream");
});