let Basic = document.getElementById("Basic");
let Standard = document.getElementById("Standard");
let Premium = document.getElementById("Premium");
let chocolate = document.getElementById("chocolate");
let strawberry = document.getElementById("strawberry");
let pista = document.getElementById("pista");
let oreo = document.getElementById("oreo");



Basic.addEventListener('click', () => {
    alert("You have purchased the basic plan");
});

Standard.addEventListener('click', () => {
    alert("You have purchased the Standard plan");
});



Premium.addEventListener('click', () => {
    alert("You have purchased the Premium plan");
});
